SELECT
  Participant_Code,
  Facility_Code,
  Status,
  year(Start_Time) as Year,
  round(avg(Outage_MW), 2) as Avg_Outage_MW_Loss,
  round(sum(Outage_MW), 2) as Summed_Energy_Lost
FROM AEMR
WHERE
  Status = 'Approved'
  AND Reason = 'Forced'
GROUP BY
  Facility_Code, Participant_Code, Year
ORDER BY
  Year, Summed_Energy_Lost DESC;



